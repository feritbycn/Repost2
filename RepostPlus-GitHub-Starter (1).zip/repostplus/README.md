# RepostPlus — UI Starter

Modern, responsive React + Vite prototype for a social-link saving and repost assistant. Turkish interface, dark navy / cyan / violet visual system.

## Run locally

```bash
npm install
npm run dev
```

Create production build:

```bash
npm run build
```

## Included in this prototype
- Responsive dashboard and branded UI
- Link input and demo link analysis flow
- Content preview, caption display and copy-to-clipboard action
- Target platform selector (Instagram, TikTok, X, YouTube, Facebook, WhatsApp)
- History/library with platform filters and search
- Save link to local in-memory history (resets on refresh)
- Pro upsell screen and subscription feature presentation
- Modern bottom-right RepostPlus watermark on the content preview
- Watermark-removal choice modal: rewarded-ad demo or Pro upsell
- Share action uses the native Web Share API when supported, with clipboard fallback
- Sign-in/register modal UI, rating UI, collections UI, settings/help entries
- SVG-independent CSS logo mark and custom gradient art

## Important: what is not connected yet
This repository is a **front-end prototype**, not a production downloader. The preview uses demo data. Real media extraction, platform-native incoming share-target integration, account creation, cloud-synced history, ratings submission, rewarded ads and paid subscriptions need backend/provider integrations. Watermark removal currently demonstrates the UX only; no ad is actually served and no watermark is processed out of a downloaded media file yet.

Recommended implementation path:
1. Build a backend API for URL validation, metadata and supported media resolution. Use official APIs or authorized providers; respect each platform's terms, copyright and privacy rules. Do not bypass private content, logins, DRM or access controls.
2. For receiving a link when a user taps Share inside Instagram/TikTok/X, implement Android Sharesheet intent filters / iOS Share Extension and app links/deep links. The web prototype can invoke the browser share sheet where supported, but cannot register itself as an incoming target in every social app. When an app shares a URL into the native app, parse that URL automatically without requiring social-account login for public content.
3. Use Firebase or Supabase for authentication and cloud history. Store URLs/metadata by default; only store media when permitted and explicitly requested.
4. Add Google AdMob rewarded ads / a consent-aware ad SDK and Google Play Billing / StoreKit for Pro. Grant one watermark-free export only after the rewarded ad completion callback; Pro users get watermark-free exports while entitlement is active. Do not ship a fake checkout; validate purchases server-side.
5. Add rate limiting, URL allowlists, SSRF protection, malware scanning, clear retention/deletion controls and privacy policy before public launch.

## Suggested stack for production
- Mobile: React Native or Flutter for native share extensions and store billing
- Web dashboard: this Vite app
- Backend: Node.js/TypeScript API + PostgreSQL
- Auth/storage: Supabase or Firebase
- Analytics/crash reports: privacy-conscious, consent-aware provider

## GitHub
Create a repository, unzip this project into it, then commit `package.json`, `index.html`, `src/`, and this README. `node_modules/` and `dist/` are intentionally not included.
