import pathlib, re, sys
root = pathlib.Path('android/app/src/main')
mf = root / 'AndroidManifest.xml'
x = mf.read_text(encoding='utf-8')
if 'android.intent.action.SEND' not in x:
    flt = '''
            <intent-filter>
                <action android:name="android.intent.action.SEND" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:mimeType="text/plain" />
            </intent-filter>'''
    x = x.replace('</intent-filter>', '</intent-filter>' + flt, 1)
    mf.write_text(x, encoding='utf-8')
java = next(root.glob('java/**/MainActivity.java'))
pkg = re.search(r'package\s+([\w.]+);', java.read_text(encoding='utf-8')).group(1)
java.write_text(f'''package {pkg};

import android.content.Intent;
import android.webkit.ValueCallback;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {{
    @Override
    protected void onNewIntent(Intent intent) {{
        super.onNewIntent(intent);
        String action = intent.getAction();
        String type = intent.getType();
        if (Intent.ACTION_SEND.equals(action) && type != null) {{
            bridge.getActivity().setIntent(intent);
            bridge.eval("window.dispatchEvent(new Event('sendIntentReceived'))", new ValueCallback<String>() {{
                @Override
                public void onReceiveValue(String s) {{}}
            }});
        }}
    }}
}}
''', encoding='utf-8')
print('android patched:', java)
