import pathlib, re, sys
root = pathlib.Path('android/app/src/main')
mf = root / 'AndroidManifest.xml'
x = mf.read_text(encoding='utf-8')
if 'android.intent.action.SEND' not in x:
    flt = '''
            <intent-filter>
                <action android:name="android.intent.action.SEND" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:mimeType="text/plain" />
            </intent-filter>'''
    x = x.replace('</intent-filter>', '</intent-filter>' + flt, 1)
    mf.write_text(x, encoding='utf-8')
java = next(root.glob('java/**/MainActivity.java'))
pkg = re.search(r'package\s+([\w.]+);', java.read_text(encoding='utf-8')).group(1)
java.write_text(f'''package {pkg};

import android.content.Intent;
import android.webkit.ValueCallback;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {{
    @Override
    protected void onNewIntent(Intent intent) {{
        super.onNewIntent(intent);
        String action = intent.getAction();
        String type = intent.getType();
        if (Intent.ACTION_SEND.equals(action) && type != null) {{
            bridge.getActivity().setIntent(intent);
            bridge.eval("window.dispatchEvent(new Event('sendIntentReceived'))", new ValueCallback<String>() {{
                @Override
                public void onReceiveValue(String s) {{}}
            }});
        }}
    }}
}}
''', encoding='utf-8')
print('android patched:', java)

# Sabit debug imzası: Google girişinin SHA-1 değeri her derlemede aynı kalsın
import os, shutil
here = pathlib.Path(__file__).parent
ks = here / 'debug.keystore'
if ks.exists():
    dst = pathlib.Path.home() / '.android'
    dst.mkdir(exist_ok=True)
    shutil.copy(ks, dst / 'debug.keystore')
    print('debug.keystore kopyalandı')

# Firebase yapılandırması (varsa)
ws = pathlib.Path(os.environ.get('GITHUB_WORKSPACE', '.'))
for cand in [pathlib.Path('google-services.json'), ws / 'google-services.json']:
    if cand.exists():
        shutil.copy(cand, 'android/app/google-services.json')
        print('google-services.json eklendi:', cand)
        break
else:
    print('UYARI: google-services.json bulunamadı, Google girişi çalışmaz')

# Google giriş kütüphanelerini APK'ya dahil et (eklentide varsayılan kapalı)
vg = pathlib.Path('android/variables.gradle')
t = vg.read_text(encoding='utf-8')
if 'rgcfaIncludeGoogle' not in t:
    i = t.rindex('}')
    t = t[:i] + "    rgcfaIncludeGoogle = true\n" + t[i:]
    vg.write_text(t, encoding='utf-8')
print('variables.gradle:', 'rgcfaIncludeGoogle = true' in vg.read_text(encoding='utf-8'))
